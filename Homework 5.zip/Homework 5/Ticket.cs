﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Homework_5
{
    //Started as an abstract class, but ended up using it to create generic tickets
    public class Ticket 
    {

        public string FileName { get; set; }

        public Ticket()
        {
            FileName = AppDomain.CurrentDomain.BaseDirectory + "Should_Never_Exist_TicketBase.csv";
        }

        //Reads the file to find the last id used
        protected int CheckTID(string file)
        {

            if (File.Exists(file))
            {

                string[] fileContent = File.ReadAllLines(file);
                string line = fileContent[fileContent.Length - 1];
                string[] lineContent = line.Split(',');

                Int32.TryParse(lineContent[0], out int tID);

                try
                {
                    return tID;
                }
                catch (Exception e)
                {
                    Console.WriteLine("ERROR: There was a problem in finding the lastest ticket ID. The file may be improperly formatted.");
                    throw e;
                }
            }
            else
            {
                return -1;
            }

            
        }

        public virtual void WriteTicket()
        {
            Console.WriteLine("This method is meant to be overidded by subclasses");
        }



    }
}
